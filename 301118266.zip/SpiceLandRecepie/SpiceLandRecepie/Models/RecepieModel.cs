﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiceLandRecepie.Models
{
    public class RecepieModel

    {
        public string recepieName { get; set; }
        public string ingrediants { get; set; }
        public string chefsName { get; set; }
        public int time { get; set; }

    }
}
