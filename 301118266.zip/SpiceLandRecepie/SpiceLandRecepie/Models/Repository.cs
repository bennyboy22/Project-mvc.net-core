﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiceLandRecepie.Models
{
    public static class Repository
    {

  
         private static List<RecepieModel> recepies = new List<RecepieModel>();
    
        public static List<RecepieModel> Recepies
        {
            get
            {
                return recepies;
            }
        }

        public static void AddRecipies(RecepieModel recepie)
        {
            recepies.Add(recepie);
        }
    }
}
