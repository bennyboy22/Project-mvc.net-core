﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SpiceLandRecepie.Models;

namespace SpiceLandRecepie.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }
        [HttpGet]
        public ViewResult AddRecipe()
        {
            return View();
        }
        [HttpPost]
        public ViewResult AddRecipe(RecepieModel recepie)
        {
            Repository.AddRecipies(recepie);
            return View("ThankYou");        }

        public ViewResult RecipeList()
        {
            return View(Repository.Recepies.OrderBy(p => p.recepieName).ToList<RecepieModel>());
        }

        public ViewResult ViewRecipe()
        {
            return View();
        }
        public ViewResult ReviewRecipe()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public ViewResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
